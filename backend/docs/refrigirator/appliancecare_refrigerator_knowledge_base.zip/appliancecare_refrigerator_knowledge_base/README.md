# ApplianceCare AI — Refrigerator Knowledge Base

## Included files
- `diagnostic_trees/common.json` — common issue trees REF01–REF15.
- `diagnostic_trees/single_door.json` — SDF01–SDF05.
- `diagnostic_trees/double_door.json` — DDF01–DDF05.
- `maintenance_manual.txt` — cleaning and preventive maintenance.
- `technical_specs_and_electrical_diagnostics.txt` — specification template and technician-only diagnostic workflow.
- `warranty_and_service_policy.txt` — policy template without unverified durations.
- `manufacturer_error_codes.json` — code examples explicitly marked unverified for the example models.
- `model_specifications.json` — model profiles and fields to verify.
- `parts_reference.json` — starter parts catalog with compatibility controls.
- `installation_guide.txt` — installation/commissioning checklist.
- `food_storage_guidance.txt` — food storage and hygiene guidance.
- `service_workflow.json` — safety screen, intake, routing, and service-case workflow.
- `maintenance_faq.txt` — customer-facing FAQ.
- `manifest.json` — package file manifest and validation summary.

## Accuracy constraints
The example profiles `GL-D201ABCD` and `GL-N292RDSY` are carried forward from project context but are not verified against exact official model documentation here. Do not present capacities/features as confirmed facts. Error-code examples are not confirmed for these models. Populate model-specific claims only from an official source applicable to exact model and market.

## Runtime recommendations
1. Load `diagnostic_trees/common.json` plus the applicable model-specific tree.
2. Filter by model, market, verification status, and source revision.
3. Separate customer-safe guidance from technician-only procedures.
4. Use exact lookups for codes, ratings, dimensions, parts, and warranty terms rather than semantic search alone.
5. Never expose internal measurements, wiring tests, bypass instructions, or sealed-system procedures as customer DIY steps.
6. REFxx/SDFxx/DDFxx are internal ApplianceCare IDs, not manufacturer fault codes.
7. Store the official source and verification date for each model-specific claim.
