# ApplianceCare AI — Washing Machine Knowledge Base

This package contains starter knowledge-base materials for front-load and top-load washing-machine troubleshooting and service assistance.

## Files
- `diagnostic_trees/common.json` — shared symptom trees WM01–WM15.
- `diagnostic_trees/front_load.json` — front-load specific workflows FL01–FL05.
- `diagnostic_trees/top_load.json` — top-load specific workflows TL01–TL05.
- `maintenance_manual.txt` — maintenance and cleaning.
- `technical_specs_and_electrical_diagnostics.txt` — source-driven technical template and technician-only diagnostic workflow.
- `warranty_and_service_policy.txt` — warranty/service policy template without unverified durations.
- `manufacturer_error_codes.json` — empty code registry and required verification template.
- `model_specifications.json` — model registration template; no model was supplied.
- `parts_reference.json` — part categories without unverified part numbers/compatibility.
- `installation_guide.txt` — installation and commissioning.
- `laundry_guidance.txt` — loading, detergent and cycle guidance.
- `maintenance_faq.txt` — general customer-facing FAQ.
- `service_workflow.json` — safety screen, intake, routing and service case.
- `README.md` — package instructions.
- `manifest.json` — generated file inventory and JSON validation status.

## Model-specific accuracy
No exact washer model was supplied. Do not invent model names, capacity, electrical ratings, optional features, error codes, part numbers or warranty durations. Populate those fields only from official manufacturer documentation for the exact model, market and revision.

## Runtime recommendations
1. Load `diagnostic_trees/common.json` with the appropriate front-load or top-load file.
2. Determine machine type and exact model before using type/model-specific instructions.
3. Prefer exact lookups for codes, ratings, parts and warranty terms over semantic similarity alone.
4. Filter retrieval by manufacturer, model, market, source revision and verification status.
5. Separate customer-safe steps from technician-only procedures.
6. Do not advise bypassing locks, reaching into moving equipment, accessing energized parts, or testing internal electrical/mechanical components as a customer.
7. Treat WMxx, FLxx and TLxx as internal ApplianceCare IDs, never manufacturer error codes.
